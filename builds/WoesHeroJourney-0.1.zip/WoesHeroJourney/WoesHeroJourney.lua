print("WoesHeroJourney Loaded.")
